                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2845522
Clockwork Heart (dual ulysse escapement) by A26 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

So I needed a design that I could give to all of my long-distance paramours this past Valentine's Day.  I decided on a variation of my recreation of Ludwig Oeschlin's Dual Ulysse escapement since it naturally fits within a heart shape.  I explain that this model is to "count the seconds we're apart."  

Currently it is only hand-powered since I could not get my elaborate, ratcheting going-barrel to work with it.  I guess we could debate the merits of the immediacy and personal interaction with the hand-powered version vs. the design and sophistication of the spring-powered version.  Once the spring motor is more reliable, I'll upload it.  

Tolerances are pretty tight on this design (as with all radial-thrust escapements), so be mindful of how it prints (avoiding over-extrusion and elephant-footing).

I tried to modify the design so that all shafts could be 16mm x 2mm dowel pins rather than cut shafts to save time.  https://www.amazon.com/Stainless-Steel-15-8mm-Fasten-Elements/dp/B00B3MFRRK/ref=sr_1_1?ie=UTF8&qid=1522441510&sr=8-1&keywords=2mm+dowel+pin

See it in action:  https://www.youtube.com/watch?v=5OXrE8Rg4LA

UPDATE 02APR18:  
I shortened the 30T gear so that it fits the dowel pin better.  Now all shafts can be 2mm diameter x 16mm long dowel pins (as linked above) with the exception of the balance wheel shaft.  I've gotten a version working with a PLA filament strip as a shaft, so the design can meet my intent of not requiring any Dremelling.  

I also added exploded views from Openscad to show how all of the parts fit together.

UPDATE 23FEB19:
user sarf2k4 kindly posted a how it's made video via the following link: https://www.youtube.com/watch?v=VlL9tIjvARk that might prove helpful.  Be sure to check the comments section for trouble-shooting advice, but don't hesitate to comment or message if you have any issues.

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: Yes
Resolution: .15
Infill: 30

Notes: 
Printed with esun silver PLA at 205C as I wait for my Das Filament red and white PLA to arrive.